package com.example.aise_android_v1.Modelos;

public class Tareas {
}
